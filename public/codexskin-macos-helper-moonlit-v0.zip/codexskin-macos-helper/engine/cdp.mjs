import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

const LOOPBACK = new Set(['127.0.0.1', 'localhost', '[::1]']);
const VERSION = '0.1.0';

function parseArgs(argv) {
  const o = { mode: 'once', port: 9341, timeoutMs: 30000, themeDir: null, screenshot: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--probe') o.mode = 'probe';
    else if (a === '--once') o.mode = 'once';
    else if (a === '--watch') o.mode = 'watch';
    else if (a === '--verify') o.mode = 'verify';
    else if (a === '--remove') o.mode = 'remove';
    else if (a === '--check-payload') o.mode = 'check';
    else if (a === '--port') o.port = Number(argv[++i]);
    else if (a === '--timeout-ms') o.timeoutMs = Number(argv[++i]);
    else if (a === '--theme-dir') o.themeDir = path.resolve(argv[++i]);
    else if (a === '--screenshot') o.screenshot = path.resolve(argv[++i]);
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!Number.isInteger(o.port) || o.port < 1024 || o.port > 65535) throw new Error(`Invalid port: ${o.port}`);
  if (!Number.isFinite(o.timeoutMs) || o.timeoutMs < 250 || o.timeoutMs > 120000) throw new Error(`Invalid timeout: ${o.timeoutMs}`);
  return o;
}

async function readTheme(themeDir) {
  if (!themeDir) throw new Error('--theme-dir is required');
  const root = await fs.realpath(themeDir);
  const themePath = await fs.realpath(path.join(root, 'theme.json'));
  if (!path.relative(root, themePath) || path.relative(root, themePath).startsWith('..')) throw new Error('theme.json must be inside theme dir');
  const theme = JSON.parse(await fs.readFile(themePath, 'utf8'));
  if (theme.schemaVersion !== 1 || typeof theme.id !== 'string' || typeof theme.image !== 'string') throw new Error('unsupported theme.json schema');
  if (path.basename(theme.image) !== theme.image) throw new Error('theme image must be a basename');
  const imagePath = await fs.realpath(path.join(root, theme.image));
  if (path.relative(root, imagePath).startsWith('..')) throw new Error('theme image must be inside theme dir');
  const image = await fs.readFile(imagePath);
  if (image.length < 1 || image.length > 16 * 1024 * 1024) throw new Error('theme image must be 1 byte..16 MiB');
  const ext = path.extname(theme.image).toLowerCase();
  const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
  const css = await fs.readFile(path.join(root, 'codexskin.css'), 'utf8');
  const renderer = await fs.readFile(path.join(root, 'renderer-inject.js'), 'utf8');
  const artDataUrl = `data:${mime};base64,${image.toString('base64')}`;
  const revision = createHash('sha256').update(css).update(renderer).update(image).update(JSON.stringify(theme)).digest('hex').slice(0, 20);
  return { theme, css, renderer, artDataUrl, revision };
}

function validWsUrl(target, port) {
  const u = new URL(target.webSocketDebuggerUrl);
  if (u.protocol !== 'ws:' || !LOOPBACK.has(u.hostname) || Number(u.port) !== port || u.username || u.password || u.search || u.hash) throw new Error('rejected non-loopback CDP websocket');
  if (!/^\/devtools\/page\/[A-Za-z0-9._-]{1,200}$/.test(u.pathname)) throw new Error('rejected unexpected CDP websocket path');
  return u.href;
}

async function listTargets(port) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), 2000);
  try {
    const r = await fetch(`http://127.0.0.1:${port}/json/list`, { redirect: 'error', signal: controller.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const items = await r.json();
    if (!Array.isArray(items)) throw new Error('target list is not an array');
    return items.filter(x => x?.type === 'page' && String(x.url || '').startsWith('app://') && x.webSocketDebuggerUrl);
  } finally { clearTimeout(t); }
}

class Cdp {
  constructor(target, port) { this.ws = new WebSocket(validWsUrl(target, port)); this.id = 1; this.pending = new Map(); }
  async open() {
    await new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('CDP websocket open timeout')), 5000);
      this.ws.addEventListener('open', () => { clearTimeout(t); resolve(); }, { once: true });
      this.ws.addEventListener('error', () => { clearTimeout(t); reject(new Error('CDP websocket error')); }, { once: true });
    });
    this.ws.addEventListener('message', e => this.onMessage(e));
    this.ws.addEventListener('close', () => { for (const p of this.pending.values()) p.reject(new Error('CDP closed')); this.pending.clear(); });
    await this.send('Runtime.enable');
    await this.send('Page.enable');
    return this;
  }
  onMessage(e) {
    let m; try { m = JSON.parse(String(e.data)); } catch { return; }
    if (!m.id || !this.pending.has(m.id)) return;
    const p = this.pending.get(m.id); clearTimeout(p.t); this.pending.delete(m.id);
    if (m.error) p.reject(new Error(`${m.error.message} (${m.error.code})`));
    else p.resolve(m.result);
  }
  send(method, params = {}, timeoutMs = 10000) {
    const id = this.id++;
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => { this.pending.delete(id); reject(new Error(`CDP command timed out: ${method}`)); }, timeoutMs);
      this.pending.set(id, { resolve, reject, t });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expression, timeoutMs = 10000) {
    const r = await this.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }, timeoutMs);
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text || 'evaluation failed');
    return r.result?.value;
  }
  close() { try { this.ws.close(); } catch {} }
}

async function connectCodex(port, timeoutMs) {
  const deadline = Date.now() + timeoutMs; let last;
  while (Date.now() < deadline) {
    try {
      for (const target of await listTargets(port)) {
        let cdp;
        try {
          cdp = await new Cdp(target, port).open();
          const probe = await cdp.eval(`(() => ({title:document.title, href:location.href, hasBody:!!document.body, markers:{main:!!document.querySelector('main,[role="main"]'), composer:!!document.querySelector('textarea,[contenteditable="true"],.composer-surface-chrome')}}))()`);
          if (probe?.hasBody) return { cdp, probe };
          cdp.close();
        } catch (e) { cdp?.close(); last = e; }
      }
      last = new Error('no app:// page target matched');
    } catch (e) { last = e; }
    await new Promise(r => setTimeout(r, 350));
  }
  throw new Error(`No verified Codex renderer on 127.0.0.1:${port}: ${last?.message || 'timed out'}`);
}

function installExpression(payload) {
  return `(() => { const css=${JSON.stringify(payload.css)}; const art=${JSON.stringify(payload.artDataUrl)}; const theme=${JSON.stringify(payload.theme)}; const revision=${JSON.stringify(payload.revision)}; const version=${JSON.stringify(VERSION)}; const installer=${payload.renderer}; return installer(css, art, theme, {revision, version}); })()`;
}

async function injectOnce(port, themeDir, timeoutMs) {
  const payload = await readTheme(themeDir);
  const { cdp, probe } = await connectCodex(port, timeoutMs);
  try {
    await cdp.eval(installExpression(payload), 15000);
    const state = await cdp.eval(`window.__CODEXSKIN_STATE__ || null`);
    if (!state?.active || state.revision !== payload.revision) throw new Error('renderer did not acknowledge expected CodexSkin revision');
    return { state, probe };
  } finally { cdp.close(); }
}

async function verify(port, themeDir, timeoutMs, screenshot) {
  const payload = await readTheme(themeDir);
  const { cdp, probe } = await connectCodex(port, timeoutMs);
  try {
    const state = await cdp.eval(`window.__CODEXSKIN_STATE__ || null`);
    if (!state?.active) throw new Error('CodexSkin is not active in renderer');
    if (state.revision !== payload.revision) throw new Error(`revision mismatch: renderer=${state.revision} expected=${payload.revision}`);
    if (screenshot) {
      const dir = path.dirname(screenshot); await fs.mkdir(dir, { recursive: true });
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }, 15000);
      await fs.writeFile(screenshot, Buffer.from(shot.data, 'base64'));
    }
    return { state, probe, screenshot };
  } finally { cdp.close(); }
}

async function remove(port, timeoutMs) {
  const { cdp, probe } = await connectCodex(port, timeoutMs);
  try {
    await cdp.eval(`(() => { if (window.__CODEXSKIN_RESTORE__) return window.__CODEXSKIN_RESTORE__(); return false; })()`);
    const state = await cdp.eval(`window.__CODEXSKIN_STATE__ || null`);
    if (state?.active) throw new Error('restore marker still active after remove');
    return { probe };
  } finally { cdp.close(); }
}

async function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.mode === 'check') { const p = await readTheme(o.themeDir); console.log(JSON.stringify({ ok: true, mode: 'check', theme: p.theme.id, revision: p.revision, version: VERSION })); return; }
  if (o.mode === 'probe') { const targets = await listTargets(o.port); if (!targets.length) throw new Error('no loopback app:// page targets'); console.log(JSON.stringify({ ok: true, targets: targets.length })); return; }
  if (o.mode === 'once') { console.log(JSON.stringify({ ok: true, mode: 'once', ...(await injectOnce(o.port, o.themeDir, o.timeoutMs)) }, null, 2)); return; }
  if (o.mode === 'verify') { console.log(JSON.stringify({ ok: true, mode: 'verify', ...(await verify(o.port, o.themeDir, o.timeoutMs, o.screenshot)) }, null, 2)); return; }
  if (o.mode === 'remove') { console.log(JSON.stringify({ ok: true, mode: 'remove', ...(await remove(o.port, o.timeoutMs)) }, null, 2)); return; }
  if (o.mode === 'watch') {
    let lastError = null;
    for (;;) {
      try { await injectOnce(o.port, o.themeDir, o.timeoutMs); lastError = null; } catch (e) { if (e.message !== lastError) { console.error(`[codexskin] ${e.message}`); lastError = e.message; } }
      await new Promise(r => setTimeout(r, 1500));
    }
  }
}

main().catch(e => { console.error(`CodexSkin CDP: ${e.message}`); process.exit(1); });
