#!/bin/bash
set -euo pipefail
. "$(cd "$(dirname "$0")" && pwd -P)/common.sh"

PORT="$DEFAULT_PORT"
RESTART_EXISTING="false"
FOREGROUND="false"
DRY_RUN="false"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --port) PORT="${2:-}"; shift 2 ;;
    --restart-existing) RESTART_EXISTING="true"; shift ;;
    --foreground-injector) FOREGROUND="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    *) fail "Unknown apply argument: $1" ;;
  esac
done
case "$PORT" in ''|*[!0-9]*) fail "Invalid port: $PORT" ;; esac

if [ "$DRY_RUN" = "true" ]; then
  runtime_or_system_node_for_dry_run
  "$NODE" "$SCRIPT_DIR/cdp.mjs" --check-payload --theme-dir "$THEME_SRC_DIR"
  exit 0
fi

require_codex_runtime
copy_theme
"$NODE" "$SCRIPT_DIR/cdp.mjs" --check-payload --theme-dir "$THEME_DIR" >/dev/null

DEBUG_READY="false"
if verified_cdp_endpoint "$PORT"; then DEBUG_READY="true"; fi
if codex_is_running && [ "$DEBUG_READY" = "false" ]; then
  [ "$RESTART_EXISTING" = "true" ] || fail "Codex 已运行但没有已校验 127.0.0.1:$PORT CDP 端点；请关闭 Codex 或传 --restart-existing。"
  stop_codex
fi

if [ "$DEBUG_READY" = "false" ]; then
  PORT="$(select_available_port "$PORT")"
  info "launching Codex with loopback CDP port $PORT"
  launch_codex_with_cdp "$PORT"
  wait_for_cdp "$PORT" || fail "Codex 未在 45 秒内暴露 127.0.0.1:$PORT CDP 端点；查看 $APP_LOG / $APP_ERROR_LOG"
fi

if [ "$FOREGROUND" = "true" ]; then
  exec "$NODE" "$SCRIPT_DIR/cdp.mjs" --watch --port "$PORT" --theme-dir "$THEME_DIR" --timeout-ms 30000
fi

"$NODE" "$SCRIPT_DIR/cdp.mjs" --once --port "$PORT" --theme-dir "$THEME_DIR" --timeout-ms 30000 | tee "$INJECTOR_LOG"
write_state "$PORT" "" "$(codex_pids | /usr/bin/head -n 1 || true)"
info "applied CodexSkin v$SKIN_VERSION on 127.0.0.1:$PORT"
