#!/bin/bash
set -euo pipefail
. "$(cd "$(dirname "$0")" && pwd -P)/common.sh"

PORT="$DEFAULT_PORT"
PORT_EXPLICIT="false"
SCREENSHOT=""
DRY_RUN="false"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --port) PORT="${2:-}"; PORT_EXPLICIT="true"; shift 2 ;;
    --screenshot) SCREENSHOT="${2:-}"; shift 2 ;;
    --dry-run) DRY_RUN="true"; shift ;;
    *) fail "Unknown verify argument: $1" ;;
  esac
done
# State file port is the fallback (apply may auto-select a free port);
# an explicit --port always wins so users are never silently redirected.
if [ "$PORT_EXPLICIT" = "false" ] && [ -f "$STATE_PATH" ]; then
  PORT="$(state_port)"
fi

if [ "$DRY_RUN" = "true" ]; then
  runtime_or_system_node_for_dry_run
  "$NODE" "$SCRIPT_DIR/cdp.mjs" --check-payload --theme-dir "$THEME_SRC_DIR"
  exit 0
fi

require_codex_runtime
[ -d "$THEME_DIR" ] || fail "未找到已安装主题目录：$THEME_DIR；先运行 Install/Apply。"
verified_cdp_endpoint "$PORT" || fail "127.0.0.1:$PORT 不是可验证 Codex loopback CDP 端点。"
args=("$SCRIPT_DIR/cdp.mjs" --verify --port "$PORT" --theme-dir "$THEME_DIR" --timeout-ms 30000)
[ -z "$SCREENSHOT" ] || args+=(--screenshot "$SCREENSHOT")
"$NODE" "${args[@]}"
[ -z "$SCREENSHOT" ] || info "screenshot: $SCREENSHOT"
