#!/bin/bash
set -euo pipefail
. "$(cd "$(dirname "$0")" && pwd -P)/common.sh"

PORT="$DEFAULT_PORT"
PORT_EXPLICIT="false"
RESTART_CODEX="false"
DRY_RUN="false"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --port) PORT="${2:-}"; PORT_EXPLICIT="true"; shift 2 ;;
    --restart-codex) RESTART_CODEX="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    *) fail "Unknown restore argument: $1" ;;
  esac
done
# Same precedence rule as verify.sh: explicit --port beats the state file.
if [ "$PORT_EXPLICIT" = "false" ] && [ -f "$STATE_PATH" ]; then
  PORT="$(state_port)"
fi

if [ "$DRY_RUN" = "true" ]; then
  runtime_or_system_node_for_dry_run
  "$NODE" "$SCRIPT_DIR/cdp.mjs" --check-payload --theme-dir "$THEME_SRC_DIR"
  exit 0
fi

require_codex_runtime
if verified_cdp_endpoint "$PORT"; then
  "$NODE" "$SCRIPT_DIR/cdp.mjs" --remove --port "$PORT" --timeout-ms 15000
elif codex_is_running; then
  [ "$RESTART_CODEX" = "true" ] || fail "Codex 正在运行但 CDP 端点不可验证；请传 --restart-codex 或手动关闭 Codex。"
fi

if [ "$RESTART_CODEX" = "true" ]; then
  codex_is_running && stop_codex
  /usr/bin/open -na "$CODEX_BUNDLE"
fi
/bin/rm -f "$STATE_PATH"
info "restore completed; live style removed when endpoint was available; state cleared."
