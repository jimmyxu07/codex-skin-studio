#!/bin/bash
set -euo pipefail
. "$(cd "$(dirname "$0")" && pwd -P)/common.sh"

PORT="$DEFAULT_PORT"
CREATE_LAUNCHERS="true"
LAUNCH_AFTER_INSTALL="false"
DRY_RUN="false"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --port) PORT="${2:-}"; shift 2 ;;
    --no-launchers) CREATE_LAUNCHERS="false"; shift ;;
    --launch) LAUNCH_AFTER_INSTALL="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    *) fail "Unknown install argument: $1" ;;
  esac
done
case "$PORT" in ''|*[!0-9]*) fail "Invalid port: $PORT" ;; esac

if [ "$DRY_RUN" = "true" ]; then
  runtime_or_system_node_for_dry_run
  "$NODE" "$SCRIPT_DIR/cdp.mjs" --check-payload --theme-dir "$THEME_SRC_DIR"
  info "dry-run payload OK（未要求本机存在 Codex Desktop）。"
  exit 0
fi

require_codex_runtime
ensure_state_root
copy_theme
"$NODE" "$SCRIPT_DIR/cdp.mjs" --check-payload --theme-dir "$THEME_DIR" >/dev/null

# Install a self-contained copy under ~/.codex so Desktop .command launchers keep working after repo moves.
if [ "$HELPER_ROOT" != "$INSTALL_ROOT" ]; then
  /bin/mkdir -p "$(dirname "$INSTALL_ROOT")"
  tmp="$INSTALL_ROOT.installing.$$"
  prev="$INSTALL_ROOT.previous.$$"
  /bin/rm -rf "$tmp"
  /bin/mkdir -p "$tmp"
  /usr/bin/rsync -a --exclude '.DS_Store' --exclude 'test/' "$HELPER_ROOT/" "$tmp/"
  /bin/chmod 700 "$tmp"/*.command "$tmp"/engine/*.sh 2>/dev/null || true
  [ ! -e "$INSTALL_ROOT" ] || /bin/mv "$INSTALL_ROOT" "$prev"
  if ! /bin/mv "$tmp" "$INSTALL_ROOT"; then
    [ ! -e "$prev" ] || /bin/mv "$prev" "$INSTALL_ROOT"
    fail "无法安装到 $INSTALL_ROOT"
  fi
  /bin/rm -rf "$prev"
fi

if [ "$CREATE_LAUNCHERS" = "true" ]; then
  /bin/mkdir -p "$HOME/Desktop"
  /usr/bin/printf '%s\n' '#!/bin/bash' 'set -euo pipefail' "exec \"$INSTALL_ROOT/Apply CodexSkin.command\" --port $PORT --restart-existing" > "$HOME/Desktop/Apply CodexSkin.command"
  /usr/bin/printf '%s\n' '#!/bin/bash' 'set -euo pipefail' "exec \"$INSTALL_ROOT/Verify CodexSkin.command\" --port $PORT --screenshot \"$HOME/Desktop/CodexSkin Verify.png\"" > "$HOME/Desktop/Verify CodexSkin.command"
  /usr/bin/printf '%s\n' '#!/bin/bash' 'set -euo pipefail' "exec \"$INSTALL_ROOT/Restore CodexSkin.command\" --port $PORT --restart-codex" > "$HOME/Desktop/Restore CodexSkin.command"
  /bin/chmod 700 "$HOME/Desktop/Apply CodexSkin.command" "$HOME/Desktop/Verify CodexSkin.command" "$HOME/Desktop/Restore CodexSkin.command"
fi

info "installed v$SKIN_VERSION at $INSTALL_ROOT for Codex ${CODEX_VERSION:-unknown}; Node $NODE_VERSION; theme copied to $THEME_DIR"
[ "$LAUNCH_AFTER_INSTALL" != "true" ] || "$INSTALL_ROOT/engine/apply.sh" --port "$PORT" --restart-existing
