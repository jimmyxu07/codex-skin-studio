#!/bin/bash
set -euo pipefail

if [ -z "${HOME:-}" ]; then
  CURRENT_USER="$(/usr/bin/id -un)"
  HOME="$(/usr/bin/dscl . -read "/Users/$CURRENT_USER" NFSHomeDirectory 2>/dev/null | /usr/bin/awk '{print $2}')"
  export HOME
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
HELPER_ROOT="$(cd "$SCRIPT_DIR/.." && pwd -P)"
THEME_SRC_DIR="$HELPER_ROOT/theme"
INSTALL_ROOT="$HOME/.codex/codexskin-macos-helper"
STATE_ROOT="$HOME/Library/Application Support/CodexSkinMacOSHelper"
STATE_PATH="$STATE_ROOT/state.json"
THEME_DIR="$STATE_ROOT/theme"
LOG_DIR="$STATE_ROOT/logs"
APP_LOG="$LOG_DIR/codex-launch.log"
APP_ERROR_LOG="$LOG_DIR/codex-launch-error.log"
INJECTOR_LOG="$LOG_DIR/injector.log"
INJECTOR_ERROR_LOG="$LOG_DIR/injector-error.log"
DEFAULT_PORT=9341
EXPECTED_CODEX_BUNDLE_ID="com.openai.codex"
EXPECTED_CODEX_TEAM_ID="2DC432GLL2"
SKIN_VERSION="0.1.0"
export NO_PROXY="localhost,127.0.0.1,${NO_PROXY:-}"
export no_proxy="localhost,127.0.0.1,${no_proxy:-}"
unset ALL_PROXY HTTPS_PROXY HTTP_PROXY all_proxy https_proxy http_proxy || true

fail() { printf 'CodexSkin macOS helper: %s\n' "$*" >&2; exit 1; }
info() { printf 'CodexSkin macOS helper: %s\n' "$*"; }
ensure_state_root() { /bin/mkdir -p "$STATE_ROOT" "$LOG_DIR" "$THEME_DIR"; /bin/chmod 700 "$STATE_ROOT" "$LOG_DIR" "$THEME_DIR"; }

json_escape() { /usr/bin/python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$1"; }

select_available_port() {
  local requested="${1:-$DEFAULT_PORT}"
  /usr/bin/python3 - "$requested" <<'PY'
import socket, sys
start=int(sys.argv[1])
for port in [start]+list(range(9342, 9399)):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(('127.0.0.1', port))
        except OSError:
            continue
        print(port)
        raise SystemExit(0)
raise SystemExit('no available loopback port in 9341-9398')
PY
}

discover_codex_app() {
  local candidate identifier executable
  CODEX_BUNDLE=""
  for candidate in "${CODEX_APP_BUNDLE:-}" "/Applications/Codex.app" "$HOME/Applications/Codex.app" "/Applications/ChatGPT.app" "$HOME/Applications/ChatGPT.app"; do
    [ -n "$candidate" ] || continue
    [ -f "$candidate/Contents/Info.plist" ] || continue
    identifier="$(/usr/bin/plutil -extract CFBundleIdentifier raw -o - "$candidate/Contents/Info.plist" 2>/dev/null || true)"
    [ "$identifier" = "$EXPECTED_CODEX_BUNDLE_ID" ] && CODEX_BUNDLE="$candidate" && break
  done
  if [ -z "$CODEX_BUNDLE" ]; then
    while IFS= read -r candidate; do
      [ -f "$candidate/Contents/Info.plist" ] || continue
      identifier="$(/usr/bin/plutil -extract CFBundleIdentifier raw -o - "$candidate/Contents/Info.plist" 2>/dev/null || true)"
      [ "$identifier" = "$EXPECTED_CODEX_BUNDLE_ID" ] && CODEX_BUNDLE="$candidate" && break
    done < <(/usr/bin/mdfind "kMDItemCFBundleIdentifier == '$EXPECTED_CODEX_BUNDLE_ID'" 2>/dev/null || true)
  fi
  [ -n "$CODEX_BUNDLE" ] || fail "未找到官方 Codex Desktop bundle ($EXPECTED_CODEX_BUNDLE_ID)。可设置 CODEX_APP_BUNDLE=/path/to/Codex.app 后重试。"
  executable="$(/usr/bin/plutil -extract CFBundleExecutable raw -o - "$CODEX_BUNDLE/Contents/Info.plist")"
  CODEX_EXE="$CODEX_BUNDLE/Contents/MacOS/$executable"
  CODEX_VERSION="$(/usr/bin/plutil -extract CFBundleShortVersionString raw -o - "$CODEX_BUNDLE/Contents/Info.plist" 2>/dev/null || true)"
  [ -x "$CODEX_EXE" ] || fail "Codex executable missing: $CODEX_EXE"
  export CODEX_BUNDLE CODEX_EXE CODEX_VERSION
}

codesign_team_id() { /usr/bin/codesign -dv --verbose=4 "$1" 2>&1 | /usr/bin/awk -F= '/^TeamIdentifier=/{print $2; exit}'; }

require_codex_runtime() {
  [ "$(/usr/bin/uname -s)" = "Darwin" ] || fail "此 helper 只支持 macOS。"
  [ -n "${CODEX_BUNDLE:-}" ] || discover_codex_app
  CODEX_TEAM_ID="$(codesign_team_id "$CODEX_BUNDLE")"
  [ "$CODEX_TEAM_ID" = "$EXPECTED_CODEX_TEAM_ID" ] || fail "Codex Team ID 不匹配：${CODEX_TEAM_ID:-missing}，期望 $EXPECTED_CODEX_TEAM_ID。"
  /usr/bin/codesign --verify --deep --strict "$CODEX_BUNDLE" >/dev/null 2>&1 || fail "Codex .app 签名校验失败；拒绝注入。"
  RUNTIME_NODE="$CODEX_BUNDLE/Contents/Resources/cua_node/bin/node"
  [ -x "$RUNTIME_NODE" ] || fail "未找到 Codex 内置 Node：$RUNTIME_NODE。v0 按安全模型不回退到系统 Node 执行真实注入。"
  NODE_TEAM_ID="$(codesign_team_id "$RUNTIME_NODE")"
  [ "$NODE_TEAM_ID" = "$EXPECTED_CODEX_TEAM_ID" ] || fail "Codex 内置 Node Team ID 不匹配：${NODE_TEAM_ID:-missing}。"
  NODE="$RUNTIME_NODE"
  NODE_VERSION="$($NODE --version)"
  export NODE RUNTIME_NODE NODE_VERSION CODEX_TEAM_ID NODE_TEAM_ID
}

runtime_or_system_node_for_dry_run() {
  # Dry-run validates package payload even on machines without Codex Desktop.
  # When Codex Desktop is present, prefer its bundled Node (NODE exported by
  # require_codex_runtime); otherwise fall back to system node. Commands inside
  # an `if` condition are exempt from set -e, so fail()'s exit 1 here just makes
  # the condition false — no subshell needed (a subshell would lose the export).
  if discover_codex_app >/dev/null 2>&1 && require_codex_runtime >/dev/null 2>&1; then
    return 0
  fi
  NODE="$(/usr/bin/env node -e 'process.stdout.write(process.execPath)' 2>/dev/null || true)"
  [ -x "$NODE" ] || fail "dry-run 需要系统 node，当前不可用。"
  export NODE
}

copy_theme() {
  ensure_state_root
  /bin/rm -rf "$THEME_DIR"
  /bin/mkdir -p "$THEME_DIR"
  /usr/bin/rsync -a --delete "$THEME_SRC_DIR/" "$THEME_DIR/"
  /bin/chmod 600 "$THEME_DIR"/* 2>/dev/null || true
}

write_state() {
  local port="$1" injector_pid="${2:-}" codex_pid="${3:-}"
  ensure_state_root
  /usr/bin/python3 - "$STATE_PATH" "$port" "$injector_pid" "$codex_pid" "$CODEX_BUNDLE" "$NODE" <<'PY'
import json, sys, time
path, port, injector_pid, codex_pid, bundle, node = sys.argv[1:]
state = {"version":"0.1.0","status":"active","port":int(port),"injectorPid":injector_pid or None,"codexPid":codex_pid or None,"bundle":bundle,"node":node,"updatedAt":int(time.time())}
open(path,'w').write(json.dumps(state, indent=2)+"\n")
PY
  /bin/chmod 600 "$STATE_PATH"
}

state_port() { /usr/bin/python3 - "$STATE_PATH" <<'PY'
import json,sys
print(json.load(open(sys.argv[1])).get('port',''))
PY
}

codex_pids() {
  [ -n "${CODEX_EXE:-}" ] || return 0
  /bin/ps -axo pid=,command= | while read -r pid cmd; do
    case "$cmd" in "$CODEX_EXE"*) printf '%s\n' "$pid" ;; esac
  done
}

codex_is_running() { [ -n "$(codex_pids || true)" ]; }

stop_codex() {
  /usr/bin/osascript -e "tell application id \"$EXPECTED_CODEX_BUNDLE_ID\" to quit" >/dev/null 2>&1 || true
  local i
  for i in {1..40}; do codex_is_running || return 0; /bin/sleep 0.25; done
  codex_pids | while read -r pid; do [ -n "$pid" ] && /bin/kill -TERM "$pid" 2>/dev/null || true; done
  for i in {1..20}; do codex_is_running || return 0; /bin/sleep 0.25; done
  fail "无法停止正在运行的 Codex。"
}

verified_cdp_endpoint() {
  local port="$1"
  "$NODE" "$SCRIPT_DIR/cdp.mjs" --probe --port "$port" --timeout-ms 2500 >/dev/null 2>&1
}

launch_codex_with_cdp() {
  local port="$1"
  : > "$APP_LOG"; : > "$APP_ERROR_LOG"
  /usr/bin/open -na "$CODEX_BUNDLE" --args --remote-debugging-address=127.0.0.1 --remote-debugging-port="$port" >>"$APP_LOG" 2>>"$APP_ERROR_LOG"
}

wait_for_cdp() {
  local port="$1" i
  for i in {1..90}; do
    if verified_cdp_endpoint "$port"; then return 0; fi
    /bin/sleep 0.5
  done
  return 1
}
