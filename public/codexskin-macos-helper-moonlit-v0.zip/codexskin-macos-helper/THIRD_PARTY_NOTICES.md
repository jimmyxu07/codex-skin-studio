# Third Party Notices

This file lists the third-party projects and tools that informed this
helper. Trademarks of OpenAI, Codex, and ChatGPT are handled in
`NOTICE.md` §2 (they are not licensed material and do not belong in this
file).

---

## Fei-Away/Codex-Dream-Skin

- URL: <https://github.com/Fei-Away/Codex-Dream-Skin>
- macOS subdirectory used as reference: `macos/`
- Upstream `macos/LICENSE` (MIT), observed on the `main` branch on
  2026-07-20, copyright line:

  > Copyright (c) 2026 Codex Dream Skin Studio contributors

  Full MIT text is reproduced verbatim in `NOTICE.md` §1.

- Upstream `macos/NOTICE.md` declares the following files are
  **excluded from the MIT software license** (observed verbatim, dated
  2026-07-20): `presets/preset-arina-hashimoto/background.jpg`,
  `../windows/assets/dream-reference.jpg`,
  `../docs/images/presets/arina-hashimoto-source.png`,
  `../docs/images/presets/arina-hashimoto-light.jpg`,
  `../docs/images/presets/arina-hashimoto-dark.jpg`.

  **This v0 helper does not bundle, redistribute, or copy any of those
  files, and does not reference any user-provided likeness, character
  imagery, or celebrity photograph.** See `NOTICE.md` §3 for the
  provenance of the bundled background asset.

- What is reused: the **architectural route only** — loopback
  Chromium DevTools Protocol (`127.0.0.1`), no mutation of `.app` or
  `app.asar`, and a Restore launcher that fully reverses the live
  injection. The actual scripts, launchers, and CSS in this v0 helper
  were re-implemented against that route rather than copied verbatim
  (see `NOTICE.md` §1 "Modifications made in this v0 helper").

---

## Google Stitch (design tool)

- Tool URL: <https://stitch.withgoogle.com/> (Google Labs).
- Role: used only as an **image-generation tool** that produced
  `theme/background.jpg` and the design source archive at
  `design-xiu-pc-skins-v1/screens/06-moonlit-magic-workspace/06-moonlit-magic-workspace-stitch-0.jpg`
  (byte-identical, SHA-256 `be58305460c8353ed1b38f9bec3408830e4e43e63e6d7ebc64d63e76bf1d40ac`).
- No code, font, or runtime dependency from Google Stitch is bundled in
  this helper.
- The generation prompt (saved in
  `design-xiu-pc-skins-v1/screens/06-moonlit-magic-workspace/prompt.txt`)
  includes an explicit negative prompt that excludes: recognizable
  characters, anime / game / movie / novel IP, real persons,
  celebrities, watermarks, franchise logos, OpenAI / Codex / ChatGPT
  logos, school crests, and copied costumes / weapons / settings.
- The generator's terms of service govern downstream use of the
  resulting image; commercial redistribution of the bundled asset
  requires independent confirmation of those terms.

---

## Node.js (runtime)

- The helper does **not** redistribute Node.js. At runtime it uses the
  Node.js executable already signed and bundled inside the user's
  official Codex desktop application.
- For `--dry-run` mode (where Codex Desktop is not required), the
  helper uses whatever Node.js the user has on `PATH`, but only to
  validate the theme payload; no code is executed against the Codex
  renderer in that mode.