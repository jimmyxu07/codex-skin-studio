# CodexSkin macOS Helper v0

Local prototype for applying an original CodexSkin theme to Codex Desktop through loopback CDP.

## Package structure

- `Install CodexSkin.command` — install helper into `~/.codex/codexskin-macos-helper`, validate Codex signature/runtime, copy theme, create Desktop launchers.
- `Apply CodexSkin.command` — launch/restart Codex with `--remote-debugging-address=127.0.0.1`, inject the theme, write state.
- `Verify CodexSkin.command` — verify renderer marker/revision and optionally capture a screenshot.
- `Restore CodexSkin.command` — remove the live injected style and clear helper state.
- `engine/` — shell orchestration and `cdp.mjs` injector.
- `theme/` — `theme.json`, `background.jpg`, `codexskin.css`, `renderer-inject.js`.
- `NOTICE.md`, `THIRD_PARTY_NOTICES.md` — MIT attribution and security notes.

## Verified environment

End-to-end (install → apply → verify screenshot → restore) passed on:

- macOS (Mac mini), Codex Desktop `26.715.52143` shipped as `/Applications/ChatGPT.app`
  (bundle id `com.openai.codex`, Team ID `2DC432GLL2`, Chromium-based).
- Codex bundled Node `cua_node` v24.14.0.
- CDP target `app://-/index.html` with `main` + `composer` markers.

The OpenAI desktop app installs as `ChatGPT.app` but reuses the `com.openai.codex`
bundle id; `discover_codex_app` accepts both `Codex.app` and `ChatGPT.app` names,
so no manual `CODEX_APP_BUNDLE` override is needed on this build.

Verification screenshot: `docs/verify-screenshot-mac-mini-20260720.png`.

## Safety rules

- Never modifies `Codex.app`, `app.asar`, or app bundle contents.
- Only binds/probes `127.0.0.1` CDP endpoints; proxy env vars are unset for helper scripts and `NO_PROXY` includes localhost.
- Requires bundle id `com.openai.codex` and Team ID `2DC432GLL2`.
- Real apply/verify/restore uses Codex's signed bundled Node at `Contents/Resources/cua_node/bin/node`; system Node is used only for `--dry-run` payload validation when Codex Desktop is absent.

## Local commands

All four commands accept `--dry-run` (validates the theme payload with any
available Node; does not require Codex Desktop):

```bash
./Install\ CodexSkin.command --dry-run
./Install\ CodexSkin.command --port 9341
./Apply\ CodexSkin.command --port 9341 --restart-existing
./Verify\ CodexSkin.command --screenshot "$HOME/Desktop/CodexSkin Verify.png"
./Restore\ CodexSkin.command --restart-codex
```

Notes:

- `Verify`/`Restore` read the last applied port from helper state; an explicit
  `--port` always overrides it.
- `test/harness/` is a dev-only Electron harness that exercises the CDP engine
  end-to-end (probe → inject → verify + screenshot → remove) on machines
  without Codex Desktop. See `test/README.md`. It is excluded from the
  installed copy.
