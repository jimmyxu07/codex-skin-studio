/* eslint-disable no-unused-expressions */
((cssText, artDataUrl, themeConfig, meta = {}) => {
  const STYLE_ID = 'codexskin-style';
  const ART_ID = 'codexskin-art';
  const STATE_KEY = '__CODEXSKIN_STATE__';
  const restorePrevious = window.__CODEXSKIN_RESTORE__;
  if (typeof restorePrevious === 'function') restorePrevious();

  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = cssText;
  document.documentElement.appendChild(style);

  const root = document.documentElement;
  root.classList.add('codexskin-active');
  root.setAttribute('data-codexskin-theme', themeConfig.id || 'unknown');
  root.style.setProperty('--codexskin-art', `url(${artDataUrl})`);
  root.style.setProperty('--codexskin-accent', themeConfig.colors?.accent || '#c8a7ff');
  root.style.setProperty('--codexskin-accent-2', themeConfig.colors?.accentAlt || '#ffd88a');
  root.style.setProperty('--codexskin-panel', themeConfig.colors?.panel || 'rgba(24,18,48,.72)');
  root.style.setProperty('--codexskin-text', themeConfig.colors?.text || '#f8f3ff');

  const badge = document.createElement('div');
  badge.id = ART_ID;
  badge.textContent = `${themeConfig.name || 'CodexSkin'} · applied`;
  document.body?.appendChild(badge);

  const state = {
    active: true,
    version: meta.version || '0.1.0',
    revision: meta.revision,
    themeId: themeConfig.id,
    themeName: themeConfig.name,
    appliedAt: new Date().toISOString()
  };
  window[STATE_KEY] = state;
  window.__CODEXSKIN_RESTORE__ = () => {
    document.getElementById(STYLE_ID)?.remove();
    document.getElementById(ART_ID)?.remove();
    root.classList.remove('codexskin-active');
    root.removeAttribute('data-codexskin-theme');
    ['--codexskin-art','--codexskin-accent','--codexskin-accent-2','--codexskin-panel','--codexskin-text'].forEach(name => root.style.removeProperty(name));
    window[STATE_KEY] = { active: false, restoredAt: new Date().toISOString(), previousRevision: state.revision };
    return true;
  };
  return state;
})
